# backend/app/__init__.py
# Empty file to make 'app' a Python package